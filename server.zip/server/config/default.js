const config = {
    port: 3001,
    database: {
        Host: '127.0.0.1',
        USER: 'blog',
        PASSWORD: '12345678',
        DATABASE: 'blog'
    }
}
module.exports = config;