const config = {
    port: 8080,
    database: {
        Host: 'localhost',
        USER: 'root',
        PASSWORD: '12345678',
        DATABASE: 'blog'
    }
}
module.exports = config;